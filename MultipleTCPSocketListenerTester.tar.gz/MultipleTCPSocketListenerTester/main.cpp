/*
 * main.cpp
 *
 *  Created on: Mar 13, 2016
 *      Author: user
 */

#include "MTCPListenerTest.h"

using namespace std;
using namespace npl;

int main() {
	MTCPListenerTest tcpTest;
	if(!tcpTest.test()){
		cerr<<endl<<endl<<"TCP test failed"<<endl;
	}else{
		cout<<endl<<"TCP test pass"<<endl;
	}
	return 0;
}

