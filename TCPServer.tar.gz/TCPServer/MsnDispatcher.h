#ifndef TCPMESSENGERDISPATCHER_H__
#define TCPMESSENGERDISPATCHER_H__

#include <strings.h>
#include <map>
#include <vector>
#include <set>
#include "MThread.h"
#include "TCPSocket.h"
#include "MultipleTCPSocketsListener.h"
#include "TCPMessengerProtocol.h"


using namespace std;
using namespace npl;


/**
 * The dispatcher server reads incoming commands from open peers and performs the required operations
 */
class MsnDispatcher: public MThread{
	typedef map<string, TCPSocket*> tOpenedPeers;
	tOpenedPeers openedPeers;	// opened but not yet logged in
	tOpenedPeers loggedInPeers;	// logged in peers

	bool running;

public:
	/**
	 * constructor
	 */
	MsnDispatcher();
	~MsnDispatcher();

	/**
	 * The Dispatcher main loop
	 */
	void run();

	void addPeer(TCPSocket* peerSocket);

	void listPeers();

	void close();

private:

	vector<TCPSocket*> getPeersVec();

	TCPSocket* getAvailablePeerByUserName(const string &userName);
};

#endif
