#include "MsnDispatcher.h"
#include "TCPMessengerProtocol.h"
#include "TCPMessengerServer.h"

/**
 * The dispatcher server reads incoming commands from open peers and performs the required operations
 */
MsnDispatcher::MsnDispatcher(){
	running = false;
	start();
}

MsnDispatcher::~MsnDispatcher(){
}

void MsnDispatcher::run(){
	cout<<"dispatcher started"<<endl;
	running = true;
	while (running){
		MultipleTCPSocketsListener msp;
		msp.addSockets(getPeersVec());
		TCPSocket* readyPeer = msp.listenToSocket(2);
		if(readyPeer == NULL) 	// timeout
			continue;

		int command = TCPMessengerServer::readCommandFromPeer(readyPeer);
		string peerName;
		switch (command) {
		case LOGIN:
			string userPass = TCPMessengerServer::readDataFromPeer(readyPeer);
			cout<<"got login command:"<<readyPeer->destIpAndPort()<<"->"<< userPass<<endl;
			
			// TODO: parse the user and password 
			// TODO: check login info, if all is OK send LOGIN_APPROVED to peer and add the peer to the logged in map
			// TODO: if login is wrong or already logged in, send LOGIN_REFUSED to peer
		
			break;
		case EXIT:
			cout<<"got login command:"<<readyPeer->destIpAndPort()<<"->"<< userPass<<endl;
			
			// TODO: disconnect the socket, and remove from all data structures
		
			break;
		default:
			cout<<"got command:"<<command<<" from peer:"<<readyPeer->destIpAndPort()<<endl;
			break;
		}
	}
	cout<<"dispatcher ended"<<endl;
}

void MsnDispatcher::listPeers(){
	// TODO: print all peer's ip + port
}

void MsnDispatcher::close(){
	cout<<"closing dispatcher"<< endl;
	running = false;

	// TODO: close all peers
	
	waitForThread();

	// TODO: delete all peers
	
	cout<<"dispatcher closed"<< endl;
}

vector<TCPSocket*> MsnDispatcher::getPeersVec(){
	vector<TCPSocket*> vec;
	tOpenedPeers::iterator iter = openedPeers.begin();
	tOpenedPeers::iterator endIter = openedPeers.end();
	for(;iter != endIter;iter++){
		vec.push_back((*iter).second);
	}
	return vec;
}

TCPSocket* MsnDispatcher::getAvailablePeerByUserName(const string &userName){
	// TODO: return a socket of the given username
}

void MsnDispatcher::addPeer(TCPSocket* peer){
	openedPeers[peer->destIpAndPort()] = peer;
}

