//============================================================================
// Name        : UDPMessenger
// Author      : Eliav Menachi
// Version     :
// Copyright   : Your copyright notice
// Description : UDP Messenger application
//============================================================================

#include "UDPMessenger.h"

using namespace std;
using namespace npl;

void UDPMessenger::run(){
	// receiver thread...
	cout<<"closing receiver thread"<<endl;
}

UDPMessenger::UDPMessenger(){
	// init the messenger

	this->start();
}

void UDPMessenger::sendTo(string msg,string ip){

}

void UDPMessenger::reply(string msg){

}

void UDPMessenger::close(){

}

