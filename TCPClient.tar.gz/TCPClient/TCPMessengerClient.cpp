
#include "TCPMessengerClient.h"
#include "TCPMessengerProtocol.h"



/**
 * initialize all properties
 */
TCPMessengerClient::TCPMessengerClient(){
	socket = NULL;
	running = false;
	peerAddress = "";
	sessionActive = false;
	connected = false;
	serverAddress = "";
}

/**
 * client receive loop, activated once a connection to the server is established
 */
void TCPMessengerClient::run(){
	running = true;

	while(running){
		int command = readCommand();
		string msg;
		switch (command){
		case SEND_MSG_TO_PEER:
			msg = readDataFromPeer();
			cout<<">>"<<msg<<endl;
			break;
		case CLOSE_SESSION:
			cout<<"Session was closed by remote peer"<<endl;
			sessionActive = false;
			peerAddress = "";
			break;
		case OPEN_SESSION:
			peerAddress = readDataFromPeer();
			cout<<"Session was opened by remote peer: "<<peerAddress<<endl;
			sessionActive = true;
			break;
		case SESSION_ESTABLISHED:
			cout<<"Session was established with remote peer"<<endl;
			sessionActive = true;
			break;
		case SESSION_REFUSED:
			cout<<"Session was refused, requested peer not available"<<endl;
			sessionActive = false;
			break;
		default:
			cout<<"communication with server was interrupted - connection closed"<<endl;
			running = false;
			socket->close();
			connected = false;
			serverAddress = "";
			sessionActive = false;
			peerAddress = "";
			delete socket;
			break;
		}
	}
}

/**
 * connect to the given server ip (the port is defined in the protocol header file)
 */
bool TCPMessengerClient::connect(string ip){
	if(connected) disconnect();
	socket = new TCPSocket(ip,MSNGR_PORT);
	if (socket == NULL) return false;
	connected = true;
	serverAddress = ip;
	start();
	return true;
}

/**
 * open session with the given peer address (ip:port)
 */
bool TCPMessengerClient::open(string username){
	// TODO: implement
}

/**
 * close active session
 */
bool TCPMessengerClient::closeActiveSession(){
	sendCommand(CLOSE_SESSION);
	sessionActive = false;
	peerAddress = "";
	return true;
}

/**
 * disconnect from messenger server
 */
bool TCPMessengerClient::disconnect(){
	running = false;
	if (socket != NULL){
		if(sessionActive) closeActiveSession();
		socket->close();
		this->waitForThread();
	}
	return true;
}

/**
 * send the given message to the connected peer
 */
bool TCPMessengerClient::send(string msg){
	if(!sessionActive) return false;
	sendCommand(SEND_MSG_TO_PEER);
	sendData(msg);
	return true;
}

/**
 * return true if a session is active
 */
bool TCPMessengerClient::isActiveClientSession(){
	return sessionActive;
}

/**
 * return true if connected to the server
 */
bool TCPMessengerClient::isConnected(){
	return connected;
}



/**
 * read incoming command
 */
int TCPMessengerClient::readCommand(){
	int command;
	socket->recv((char*)&command,4);
	command = ntohl(command);
	return command;
}

/**
 * read incoming data
 */
string TCPMessengerClient::readDataFromPeer(){
	string msg;
	char buff[1500];
	int msgLen;
	socket->recv((char*)&msgLen,4);
	msgLen = ntohl(msgLen);
	int totalrc = 0;
	int rc;
	while (totalrc < msgLen){
		rc = socket->recv((char*)&buff[totalrc],msgLen-totalrc);
		if (rc>0){
			totalrc += rc;
		}else{
			break;
		}
	}
	if (rc > 0 && totalrc == msgLen){
		buff[msgLen] = 0;
		msg = buff;
	}else{
		socket->close();
	}
	return msg;
}

/**
 * send given command
 */
void TCPMessengerClient::sendCommand(int command){
	command = htonl(command);
	socket->send((char*)&command);
}

/**
 * send given message
 */
void TCPMessengerClient::sendData(string msg){
	int msgLen = msg.length();
	msgLen = htonl(msgLen);
	socket->send((char*)&msgLen);
	socket->send(msg.data());
}

